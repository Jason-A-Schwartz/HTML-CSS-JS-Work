//This creates a function for challenge one and assigns it to the challenge one button click
document.getElementById("ChallengeOneButton").onclick=function ChallengeOne(){
    
    //These create variables that accept float values and accept the user input
    var NumberOne = parseFloat(document.getElementById("ChallengeOneInputOne").value);
    var NumberTwo = parseFloat(document.getElementById("ChallengeOneInputTwo").value);
    var NumberThree = parseFloat(document.getElementById("ChallengeOneInputThree").value);
    
    //These create a variable to store the calculated results and output
    var ChallengeOneCalculationOne = NumberOne+NumberTwo+NumberThree;
    var ChallengeOneCalculationTwo = ChallengeOneCalculationOne/3;
    var ChallengeOneOutput = ("Your first number was: " + NumberOne + ", your second number was: " + NumberTwo + ", and your third number was: " + NumberThree + ". Your sum is: " + ChallengeOneCalculationOne + ", and your average is: " + ChallengeOneCalculationTwo + ".");
    
    //This uses an if else statement to check if the user input three numbers and if not tells them to do so. However, if they did input three numbers the results are output to the page
    if(isNaN(NumberOne) == true || isNaN(NumberTwo) == true || isNaN(NumberThree) == true){
        alert("ERROR: Please only enter THREE NUMBERS for challenge one");
    }
    else{
       document.getElementById("ChallengeOneResults").innerHTML = ChallengeOneOutput;
    }
}

//This creates a function for challenge two and assigns it to the challenge two button click
document.getElementById("ChallengeTwoButton").onclick=function ChallengeTwo(){
    
    //This creates a varialbe to accept the user input name
    var NameInput = document.getElementById("ChallengeTwoInputOne").value;
    
    //This creates a variable and stores the length of the user input name
    var LetterCount = NameInput.length;
    
    //This stores an empty value for the name evaluation
    var NameLength = "";
    
    //This checks the length of the input name and determines if it's short, average, or long. Then it assigns the corresponding value to the NameLength variable
    if(LetterCount <5){
        NameLength = "short";
    }
    else if (LetterCount <9){
        NameLength = "average";
    }
    else{
        NameLength = "long"; 
    }
    // This stores the the output in a variable
    var ChallengeTwoOutput = ("Your first name is: " + NameInput + ", and it has: " + LetterCount + " letters. However, your name is considered to be: " + NameLength + " in terms of length.");
    
    //This makes sure that the user inputs a string with no spaces and gives them a error if so. However, if they do input a string with no spaces the results are displayed
     if(NameInput != "" && isNaN(NameInput) == true && NameInput.includes(" ") == false){
         document.getElementById("ChallengeTwoResults").innerHTML = ChallengeTwoOutput;
    }
    else{
        alert("ERROR: Please only enter your FIRST NAME for challenge two");
    }
}

//This establishes the animal array outside of the function to allow the user to keep adding to the animal list
var AnimalArray = ["Zebra","Giraffe","Lion"];

//This creates a function for challenge three and assigns it to the challenge three button click
document.getElementById("ChallengeThreeButton").onclick=function ChallengeThree(){
    
    //This creates a varialbe to accept the user input animal
    var AnimalInput = document.getElementById("ChallengeThreeInputOne").value;
    
    //This makes sure that the user inputs a non duplicate string with no spaces and gives them a error if so. However, if they do input a string (not in the array) with no spaces then the results are displayed
    if(AnimalInput != "" && isNaN(AnimalInput) == true && AnimalInput.includes(" ") == false && AnimalArray.includes(AnimalInput) == false){
        
        //This appends the user input to the end of the array
        AnimalArray.push(AnimalInput);
        
        //This stops the list from repeating itself
        ChallengeThreeResults.innerHTML = "";
        
        //This loops through the array (based of its own length) to output the list with the user input animal
        for(var x = 0; x < AnimalArray.length; x++){
            
            ChallengeThreeResults.innerHTML += "<li>" + AnimalArray[x] + "</li>";
        }
    }
    else{
        alert("ERROR: Please only enter a NEW ANIMAL for challenge three");
    }
}

//This creates a function for challenge four and assigns it to the challenge four button click
document.getElementById("ChallengeFourButton").onclick=function ChallengeFour(){
    
    //This creates an object for challenge four and assigns the required data and functions 
    var MyInfo = {
    FavColor: "red",
    Age: 21,
    FavQuote: function QuoteAlert(){
        alert('"The only thing we have to fear is fear itself. - FDR"')
    }
  };
    
    //This uses the MyInfo object to calculate how many years it will take for me to reach 100 (based on my current age) and then stores it into a variable
    AgeResult = 100 - MyInfo.Age;
    
    //This uses the MyInfo object to alert the user what my favorite color is and how many years I need to reach 100
    alert("My favorite color is: " + MyInfo.FavColor + ", and in " + AgeResult + " years I will be 100.");
    
    //This alerts the user with what my favorite quote is through the function stored in the MyInfo object
    MyInfo.FavQuote();
}