// This slideshow code is from: https://www.w3schools.com/howto/howto_js_slideshow.asp
var slideIndex = 0;

showSlides();

function showSlides() {
    
  var i;
    
  var slides = document.getElementsByClassName("mySlides");
    
  for (i = 0; i < slides.length; i++) {
      
    slides[i].style.display = "none";
      
  }
    
  slideIndex++;
    
  if (slideIndex > slides.length) {
      
      slideIndex = 1;
  }
    
  slides[slideIndex-1].style.display = "block";
    
  setTimeout(showSlides, 2000);
}
// This is the end of the slideshow code

function BuyOne(){
    alert("Thank you! The Valentine Hedgehog has been set as your box and will be charged to your account. You are still able to switch as long as your order has not shipped yet.")
}

function BuyTwo(){
    alert("Thank you! The Silly Frog has been set as your box and will be charged to your account. You are still able to switch as long as your order has not shipped yet.")
}
function BuyThree(){
    alert("Thank you! The Cute Elephant has been set as your box and will be charged to your account. You are still able to switch as long as your order has not shipped yet.")
}
function SignOut(){
    location.href = "SignUpIn.php";
}