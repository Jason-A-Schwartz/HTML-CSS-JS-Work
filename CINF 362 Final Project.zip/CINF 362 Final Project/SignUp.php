<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">   
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <title>Sign Up</title>
    <link rel="stylesheet" href="css/final_css.css">
</head>
    <body>
        <div class="container">
            <div class="row header">
                <nav>
                    <a href="Home.html" title="Brings you to the Home page">Home</a>
                    <a href="SignUp.php" title="Brings you to the Sign Up/In page">Sign Up</a>
                    <a href="Shop.html" title="Brings you to the Shop page">Shop</a>
                    <a href="FAQ.html" title="Brings you to the FAQ page">FAQ</a>
                    <a href="ContactUs.html" title="Brings you to the Contact Us page">Contact Us</a>
                </nav>
            </div>
            <div class="Sidebar">
            </div>
            <div class="MainContent">
                <div class="SignInBoxContainer">
                    <div class="SignInBox">
                        <!-- This image is from: https://www.reddit.com/r/facebook/comments/m952z2/why_is_my_facebook_account_displaying_new_blank/ -->
                        <img src="images/ProfilePic.png" alt="Profile Picture">
                        <div class="SignUpTextController">
                            <p><b>Please fill out a username &amp; password in order to be able to purchase monthly boxes</b>
                        <br>
                        <br>
                           <i>Your username &amp; password must be at least 5 characters long</i></p>
                        </div>
                         <form method="get">
                            <label for="Username">Username:</label>
                            <input id="Username" name="Username" type="text">
                            <label for="Password">Password:</label>
                            <input id="Password" name="Password" type="text">
                            <button id="submit" name="submit" type="submit">Sign Up</button>
                        </form>
                        <br>
                        <div class="PHPCenter">
                            <?php
                            
                            // This code section for table creation is from: https://www.w3schools.com/php/php_mysql_create_table.asp
                            $servername = "localhost";
                            $username = "id18376786_siteuser";
                            $password = "<x-y@>78C@*Z8F?e";
                            $dbname = "id18376786_jasondb";
                            // Create connection
                            $conn = new mysqli($servername, $username, $password, $dbname);
                            // Check connection
                            if ($conn->connect_error) {
                                die("Connection failed: " . $conn->connect_error);
                            }
                            // sql to create table
                            $sql = "CREATE TABLE Users (Username VARCHAR(30) NOT NULL, Password VARCHAR(30) NOT NULL)";
                                if(isset($_GET['submit'])){
                                    if(empty($_GET['Username']) || empty($_GET['Password'])){
                                        echo "<b>ERROR: Please fill out both the Username & Password</b>";
                                        } else {
                                            if(strlen($_GET['Username'])>=5 && strlen($_GET['Password'])>=5){
                                                $Username = $_GET['Username'];
                                                $Password = $_GET['Password'];
                                                // This code section for insert is from: https://www.w3schools.com/php/php_mysql_insert.asp
                                                $sql = "INSERT INTO Users (Username,Password)
                                                VALUES ('$Username','$Password')";
                                                if ($conn->query($sql) === TRUE) {
                                                    echo "<b>Thank you for creating an account!</b>";
                                                }
                                        } else{
                                                echo "<b>ERROR: Please make sure your Username & Password are at least 5 characters long!</b>";
                                  }
                                 }
                                }
                            ?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="Sidebar">
            </div>
            <div class="footer">
                <p>&copy; Jason Schwartz</p>
            </div>
        </div>
    </body>
</html>