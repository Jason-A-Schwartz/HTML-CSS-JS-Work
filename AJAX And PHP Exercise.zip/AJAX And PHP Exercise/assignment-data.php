<?php
$fruitsArray = array("Acerola", "Apple", "Apricot", "Avocado", "Banana", "Blackberries", "Bluerberries", "Cantaloupe", "Carambola", "Cherimoya", "Cherries", "Clementine", "Crannberries", "Dates", "Durian", "Elderberries", "Feijoa", "Figs", "Gooseberries", "Grapefruit", "Grapes", "Honeydew Melon", "Jujube Fruit", "Kiwi", "Kumquat", "Lemon", "Lime", "Mandarin", "Mango", "Nectarine", "Olive", "Orange", "Papaya", "Peaches", "Pear", "Pineapple", "Plantain", "Plum", "Pomegranate", "Quince", "Raspberries", "Strawberries", "Tamarind", "Tangerine", "Watermelon");

$returnedFruit = "";

if ($_SERVER['REQUEST_METHOD'] == "GET") {
    
    $submittedFruit = $_GET['fruitInput'];
    
    foreach($fruitsArray as $fruit) {
        
        if (stripos($fruit,$submittedFruit) === 0) {
            $returnedFruit .= "<p>$fruit</p>";
        } 
    }
}
if ($returnedFruit != "") {
    echo $returnedFruit;
    
} else {
    echo  "<p>No fruit found.</p>";
}
?>