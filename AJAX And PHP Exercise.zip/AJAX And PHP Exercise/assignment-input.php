<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>AJAX &amp; PHP Exercise</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        * {
            box-sizing: border-box;
        }

        .container {
            max-width: 800px;
            margin: 0 auto;
            border: 2px solid black;
            padding: 0 1em 1em;
            border-bottom-left-radius: 10px;
            border-bottom-right-radius: 10px;
        }

        h1 {
            max-width: 800px;
            margin: 0 auto;
            background: #46166b;
            color: #EEB211;
            padding: .25em;
            border: 2px solid black;
            border-top-left-radius: 10px;
            border-top-right-radius: 10px;
        }
    </style>
</head>
<body>
    <h1>AJAX &amp; PHP Exercise</h1>
    <div class="container">
        <p>Your task is to use AJAX to pull data from a PHP page and display it on this page. The page with the data you want is "assignment-data.php" and it contains an array with numerous fruits. You'll add HTML/JS to this page and PHP code to the other page to complete this assignment.</p>
        <h3>Fruit Autofiller</h3>
        <input id="fruitInput" name="fruitInput" type="text">
        <div id="fruitOutput"><p>Please enter a fruit.</p></div>
        
        <script>
            
            document.getElementById("fruitInput").onkeyup = function() {
                
                var fruit = this.value;
            
                if (fruit === "") {
                    
                    document.getElementById("fruitOutput").innerHTML = "<p>Please enter a fruit.</p>";
                    
                } else {
                    
                    var myRequest = new XMLHttpRequest();
                    
                    myRequest.onreadystatechange = function() {
                        
                        if(this.status == 200 && this.readyState == 4) {
                            
                            document.getElementById("fruitOutput").innerHTML = this.responseText;
                        }
                    }
                    
                    myRequest.open("GET", "assignment-data.php?fruitInput=" + fruit, true);
                    myRequest.send();
                }
                }
        </script>
    </div>
</body>
</html>