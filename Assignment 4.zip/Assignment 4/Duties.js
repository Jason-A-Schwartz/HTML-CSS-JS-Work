function JobDOne() {
            
    var x = document.getElementById('JobDutiesOne').value;
    var points=["Cashier","Janitor","Barista","Server","Cook"];
    var y = x-1;
    var multiple ="";
    
    while(y >= 0 && x<6){
        
        multiple+= points[y]+ "<br>";
        document.getElementById("OutputOne").innerHTML=multiple;
        y--;
        
    }
    
}

function JobDTwo() {
            
    var x = document.getElementById('JobDutiesTwo').value;
    var points=["CEO","Manager","Janitor","Assistant","Cashier"];
    var y = x-1;
    var multiple ="";
    
    while(y >= 0 && x<6){
        
        multiple+= points[y]+ "<br>";
        document.getElementById("OutputTwo").innerHTML=multiple;
        y--;
        
    }
    
}

function EmptyTest(){
    
     var x = document.getElementById('JobDutiesOne').value;
    
     if(x==""){
         
     alert("Please enter a number 1-5");
        
        }

}

function EmptyTestTwo(){
    
     var x = document.getElementById('JobDutiesTwo').value;
    
     if(x==""){
         
     alert("Please enter a number 1-5");
        
        }

}


