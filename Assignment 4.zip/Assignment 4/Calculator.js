function Calculate() {
            
    var x = parseFloat(document.getElementById('WageHour').value);
    var y = parseFloat(document.getElementById('WeekHours').value);
    var w = x * y * 52;
    var z = w.toFixed(2);
    var Response;

    if (z < 20000) {
        
    Response = "Salary is too low, aim higher!";
        
  } else if (z < 25000) {
      
    Response = "Salary is almost high enough, let's negotiate.";
      
  } else {
      
    Response = "Salary is high enough and works for me.";
      
  }
    
    document.getElementById("YearlySalary").innerHTML= "The salary is $" + z + ". " + Response;
         
}

function EmptyTest(){
    
     var x = document.getElementById('WageHour').value;
     var y = document.getElementById('WeekHours').value;
    
    if(x=="" && y==""){
        
     alert("Please enter Hourly Wage and Hours Per Week");
        
        }
    
     else if(x==""){
         
     alert("Please enter Hourly Wage");
        
        }
    else if(y==""){
        
        alert("Please enter Hours Per Week");
    }

}
