<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>PHP Exercise</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        body {
            max-width: 600px;
            margin: 0 auto;
            padding: 0 1em;
            font-size: 1.25em;
        }
        input, label, button {
            display: block;
        }
        input {
            margin-bottom: 1em;
        }
    </style>
</head>

<body>
    <h1>PHP Exercise Input Page</h1>
    <p>Create a form that takes in three inputs. The three inputs are width, height, and color. After the user clicks submit, the information should be sent to the output.php page. On that page, you should have PHP code to check if the inputs were valid. Specifically, you should make sure that the inputs aren't empty and that the height/width inputs are non-zero numbers. Refer to the class examples on input validation and input/output for help with this assignment.</p>
    
    <p>Feel free to try 300, 300, aquamarine for your inputs. You can include 2px solid black, and whatever message you'd like for the extra credit portion. </p>
    
    <form action="output.php" method="get">
        
        <label for="width">Width:</label>
        <input id="width" name="width" type="text">
        <label for="height">Height:</label>
        <input id="height" name="height" type="text">
        <label for="color">Color:</label>
        <input id="color" name="color" type="text">
        <label for="border">Border Size:</label>
        <input id="border" name="border" type="text">
        <label for="message">Message:</label>
        <input id="message" name="message" type="text">
        <button id="submit" name="submit" type="submit">Submit Info</button>
    </form>
    
</body>

</html>
